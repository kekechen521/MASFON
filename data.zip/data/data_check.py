import pandas as pd

# 替换成你的实际文件路径
file_path1 = "./bioinfer/BioInfer_test.csv"
file_path2 = "./ddi/DDI_test.csv"
file_path3 = "./BioRED/BioRed_test.csv"

# 读取 CSV，utf-8-sig 可以处理可能的 BOM
df1 = pd.read_csv(file_path1, encoding="utf-8-sig")
df2 = pd.read_csv(file_path2, encoding="utf-8-sig")
df3 = pd.read_csv(file_path3, encoding="utf-8-sig")

# 去掉 label 两边可能存在的空格
df1["label"] = df1["label"].astype(str).str.strip()
df2["label"] = df2["label"].astype(str).str.strip()
df3["label"] = df3["label"].astype(str).str.strip()


# 统计每个 label 的数量
counts1 = df1["label"].value_counts()
print(counts1)

counts2 = df2["label"].value_counts()
print(counts2)


counts3 = df3["label"].value_counts()
print(counts3)
